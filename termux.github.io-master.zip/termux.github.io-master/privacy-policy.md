---
layout: page
title: Privacy Policy
---

Termux is required by Google Play to have a privacy policy:

Termux does not record any personal information and requests permissions only for different apps to function properly without sending any data over the network in the background.

The web server which serves packages records a log of remote IP, access time and what is being accessed. This information is only stored for troubleshooting purposes and is not shared with any third parties.
