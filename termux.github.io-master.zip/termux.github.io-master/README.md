Termux.com
==========
[![Join the chat at https://gitter.im/termux/termux](https://badges.gitter.im/termux/termux.svg)](https://gitter.im/termux/termux)

This is the source repository for [termux.com](https://termux.com).

Running locally
---------------
Install dependencies as explained at [Using Jekyll with Pages](https://help.github.com/articles/using-jekyll-with-pages/), then run

    bundle exec jekyll serve

to start a local server at http://localhost:4000.
